//
//  UIButton+MPAdditions.h
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (MPAdditions)

@property (nonatomic) UIEdgeInsets mp_TouchAreaInsets;

@end
